public static class GameTags
{
    public const string Obstacle = "Obstacle";
}
